	printRecur(2);
	printf("\n");
	printRecur(4);
	printf("\n");
	printRecur(6);
	printf("\n");
	printRecur(8);