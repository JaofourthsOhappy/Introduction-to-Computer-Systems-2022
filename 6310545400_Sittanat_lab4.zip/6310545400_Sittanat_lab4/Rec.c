#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/** = number of times c occurs in s.
Example: numberc('a', "aaabbbaccabda") == 6
*/
int numberc(char c, char* s) {
	if (s[0] == '\0'){
		return 0;
	}
	if (*s == c){
		return 1 + numberc(c, s + 1);
	}
	return numberc(c, s + 1);

}

 /** = number of chars in s that are not c. 
Example: numberNotc('a', "aaabbbaccabda") == 7)
 */
int numberNotc(char c, char* s) {
	if (s[0] == '\0'){
		return 0;
	}
	if (*s != c){
		return 1 + numberNotc(c, s + 1);
	}
	return numberNotc(c, s + 1);

}

/** = a copy of s but with all occurrences of c replaced by d.
Example: replace("abeabe", 'e', '$') = "ab$ab$".
*/
char* replace(char* s, char c, char d) {
	char *temp;
	temp = (char *)(malloc(sizeof(s)));
	if (s[0] == '\0'){
		return "";
	}
	if (s[0] == c){
		temp[0] = d;
	}
	else{
		temp[0] = s[0];
	}
	return strcat(temp, replace(s + 1, c, d));
}


 /** = a copy of s with adjacent duplicates removed.
 Example: for s = "abbcccdeaaa", the answer is "abcdea".*/
 char* rem1(char* s) {
	char *temp;
	temp = (char *)(malloc(sizeof(s)));
	if (s[0] == '\0'){
		return "";
	}
	if (s[0] != s[1]){
		temp[0] = s[0];
		return strcat(temp, rem1(s + 1));
	}
	if (s[0] == s[1]){
		return strcat(temp, rem1(s + 1));
	}
}


/** = number of the digits in the decimal representation of n.
e.g. numDigits(0) = 1, numDigits(3) = 1, numDigits(34) = 2.
numDigits(1356) = 4.
Precondition: n >= 0. */
int numDigits(int n) {
	if (n < 10){
		return 1;
	}
	return 1 + numDigits(n/10);
}

/** = sum of the digits in the decimal representation of n.
e.g. sumDigits(0) = 0, sumDigits(3) = 3, sumDigits(34) = 7,
sumDigits(345) = 12.
Precondition: n >= 0. */
int sumDigits(int n) {
	if (n < 10){
		return n;
	}
	return (n % 10 + sumDigits(n / 10));

}

/** = a copy of s with to_remove_char removed.
Example: removeChar("abeabe", 'e') = "abab". */
char* removeChar(char* s, char to_remove_char) {
	char *temp;
	temp = malloc(sizeof(s));
	if (s[0] == '\0'){
		return "";
	}
	if (s[0] == to_remove_char){
		return strcat(temp, removeChar(s + 1, to_remove_char));
	}
	if (s[0] != to_remove_char){
		temp[0] = s[0];
		return strcat(temp, removeChar(s + 1, to_remove_char));
	}
}

/** = a copy of s with characters in reverse order.
Example: reverse("abcdefg") = "gfedcba". */
char *reverse(char *s) {
	if (*s){
		reverse(s + 1);
		printf("%c", *s);
	}
}

int numOnes(int n){
	if (n == 0){
		return 0;
	}
	else if (n == 1){
		return 1;
	}
	else{
		return numOnes(n / 2)+numOnes(n % 2);
	}
}

void printRecur(int n){
	int num = 0;
	if (n == 1){
        printf("1");
		return;
	}
	printRecur(n - 1);
	printf(" ");
	for (int i = 0; i < n; i++){
		num++;
	}
	printf("%d", num);
	printf(" ");
	printRecur(n - 1);
}

int main() {
	char s1[] = "aaabbbaccabda";
	// Test 1
	printf("%d\n", numberc('a', "aaabbbaccabda"));
	printf("%d\n",  numberc('a', "aaa"));
	printf("%d\n",  numberc('b', "aaa"));
	printf("%d\n",  numberc('c', "aaacccccccccb"));

	//Test 2
	printf("%d\n", numberNotc('a', "aaabbbaccabda"));
	printf("%d\n",  numberNotc('a', "aaa"));
	printf("%d\n",  numberNotc('b', "aaa"));
	printf("%d\n",  numberNotc('c', "aaacccccccccb"));

	//Test 3
	printf("%s\n", replace("abeabe", 'e', '$'));
	printf("%s\n", replace("abeabe", 'a', '&'));
	printf("%s\n", replace("aabe", 'b', 'p'));
	printf("%s\n", replace("eabe", 'e', '$'));

	//Test 4
	printf("%s\n", rem1("abbcccdeaaa"));
	printf("%s\n", rem1("aaaaaabbcccdeaaa"));
	printf("%s\n", rem1("abbbbbbcccdddddeaaa"));
	printf("%s\n", rem1("aaaaaaaaaaaaaa"));

	//Test 5
	printf("%d\n", numDigits(3));
	printf("%d\n", numDigits(34));
	printf("%d\n", numDigits(345));
	printf("%d\n", numDigits(3456));

	//Test 6
	printf("%d\n", sumDigits(3));
	printf("%d\n", sumDigits(34));
	printf("%d\n", sumDigits(345));
	printf("%d\n", sumDigits(3456));

	//Test 7
	printf("%s\n", removeChar("abeab", 'e'));
	printf("%s\n", removeChar("abeab", 'a'));
	printf("%s\n", removeChar("abeab", 'b'));
	printf("%s\n", removeChar("abffeab", 'f'));

	//Test 8
	printf("%s\n", reverse("abcdefg"));
	printf("%s\n", reverse("hijk"));
	printf("%s\n", reverse("lmnop"));
	printf("%s\n", reverse("qrstuv"));

	//Test 9
	printf("%d\n", numOnes(7));
	printf("%d\n", numOnes(10));
	printf("%d\n", numOnes(3));
	printf("%d\n", numOnes(2));

	//Test 10
	printRecur(2);
	printf("\n");
	printRecur(4);
	printf("\n");
	printRecur(6);
	printf("\n");
	printRecur(8);
}
