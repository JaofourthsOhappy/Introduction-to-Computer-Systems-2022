#include <stdio.h>
#include <stdlib.h>

struct node {
    int data;
    struct node* left;
    struct node* right;
};

struct node* newNode(int data) {
  struct node* node = (struct node*)malloc(sizeof(struct node));
  node->data = data;
  node->left = NULL;
  node->right = NULL;

  return(node);
}

struct node* insert(struct node* node, int data) {
  // 1. If the tree is empty, return a new, single node
  if (node == NULL) {
    return(newNode(data));
  }
  else {
    // 2. Otherwise, recur down the tree
    if (data <= node->data) node->left = insert(node->left, data);
    else node->right = insert(node->right, data);

    return(node); // return the (unchanged) node pointer
  }
}

void printTree(struct node* root, int level ) {
  int i;
  if (root != NULL) {
    printTree(root->right, level+1);
    for (i=0; i<level; i++) printf("  ");
    printf("%d", root->data);
    printf("\n");
    printTree(root->left, level+1);
  }
}

int search(int x, struct node *root){
  if (root == NULL){
    return 0;
  }
  if (root -> data == x){
    return 1;
  }
  if (x > root -> data){
    return search(x, root -> right);
  }
  if (x < root -> data){
    return search(x, root -> left);
  }
}

int size(struct node* node){
  int node_sum = 0;
  if (node == NULL){
    return 0;
  }
  if (node -> left && node -> right){
    node_sum++;
  }
  node_sum += (size(node -> left) + size(node -> right));
  return node_sum;
}

int maxDepth(struct node* node){
  if (node == NULL){
    return -1;
  }
  else{
    int right_depth = maxDepth(node -> right);
    int left_depth = maxDepth(node -> left);
    if (left_depth < right_depth){
      return right_depth + 1;
    }
    else{
      return left_depth + 1 ;
    }
  }
}

int minValue(struct node* node){
  struct node* now = node;
  while (now -> left != NULL){
    now = now -> left;
  }
  return now -> data;
}

void printPreOrder(struct node* node){
  if (node == NULL){
    return;
  }
  printf("%d", node -> data);
  printPreOrder(node -> left);
  printPreOrder(node -> right);
}

void printPostorder(struct node* node){
  if (node == NULL){
    return;
  }
  printPreOrder(node -> left);
  printPreOrder(node -> right);
  printf("%d", node -> data);
}

void printOrder(struct node* node){
  if (node == NULL){
    return;
  }
  printPreOrder(node -> left);
  printf("%d", node -> data);
  printPreOrder(node -> right);
}

int sameTree(struct node* a, struct node* b){
  if (a == NULL && b == NULL){
    return 0;
  }
  if (a != NULL && b == NULL){
    int right = sameTree(a -> right, b -> right);
    int left = sameTree(a -> left, b -> left);
    if (a -> data == b -> data && left && right){
      return 1;
    }
    else return 0;
  }
}

int main(int argc, char** argv) {
  FILE *f, *a, *b, *c;
  int i;
  struct node *root;
  root = NULL;
  f = fopen(argv[1],"r");
  while (fscanf(f, "%d", &i) != EOF) {
    root = insert(root, i);
  }
  struct node *root2;
  root2 = NULL;
  a = fopen(argv[2],"r");
  while (fscanf(a, "%d", &i) != EOF) {
    root2 = insert(root2, i);
  }
  struct node *root3;
  root3 = NULL;
  b = fopen(argv[3],"r");
  while (fscanf(b, "%d", &i) != EOF) {
    root3 = insert(root3, i);
  }
  struct node *root4;
  root4 = NULL;
  c = fopen(argv[4],"r");
  while (fscanf(c, "%d", &i) != EOF) {
    root4 = insert(root4, i);
  }
  printTree(root, 0);
  //Test 1
  // printf("%d\n", search(70, root));
  // printf("%d\n", search(8, root));
  // printf("%d\n", search(40, root));
  // printf("%d\n", search(36, root));

  //Test 2
  // printf("%d\n", size(root));
  // printf("%d\n", size(root2));
  // printf("%d\n", size(root3));
  // printf("%d\n", size(root4));

  //Test 3
  printf("%d\n", maxDepth(root));
  printf("%d\n", maxDepth(root2));
  printf("%d\n", maxDepth(root3));
  printf("%d\n", maxDepth(root4));

  //Test 4
  // printf("%d\n", minValue(root));
  // printf("%d\n", minValue(root2));
  // printf("%d\n", minValue(root3));
  // printf("%d\n", minValue(root4));

  //Test 5
  // printPreOrder(root);
  // printf("\n");
  // printPreOrder(root2);
  // printf("\n");
  // printPreOrder(root3);
  // printf("\n");
  // printPreOrder(root4);
  // printf("\n");

  //Test 6
  // printPostorder(root);
  // printf("\n");
  // printPostorder(root2);
  // printf("\n");
  // printPostorder(root3);
  // printf("\n");
  // printPostorder(root4);
  // printf("\n");

  //Test 7
  // printOrder(root);
  // printf("\n");
  // printOrder(root2);
  // printf("\n");
  // printOrder(root3);
  // printf("\n");
  // printOrder(root4);
  // printf("\n");

  //Test 8
  // printf("%d", sameTree(root,root2));
  // printf("\n");
  // printf("%d", sameTree(root3,root4));
  // printf("\n");
  // printf("%d", sameTree(root2,root3));
  // printf("\n");
  // printf("%d", sameTree(root4,root2));
  // printf("\n");
}
